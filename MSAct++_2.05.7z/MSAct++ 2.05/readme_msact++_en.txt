﻿
	 		      MSAct++ от Ratiborus
			————————————————————————————


 			  The purpose of the program
                        ————————————————————————————
The program is intended for installation key and activate Windows 7-10 and Office 2010-2016.
If the set key enables activation over the network, via the Internet, the product is activated
automatically, if this does not happen and the key is not blocked - the code is issued to transfer M$
Activation Center to activate by phone.

                            Work with the program
                         ————————————————————————————
1. Select a product to install key and activation;
2. Type in the input box key the key for the selected product;
3. Click "Start".

 If the set key enables activation over the network, via the Internet, the product is activated
automatically, otherwise, if the key is not blocked, will shows the activation window by phone.
To activate by phone, you must call the Activation Center, send the code of the fields "1-9"
and to get the return code that must be entered in the field "A-H" and click "Apply Code".
If everything is completed without errors, the product is activated.

*** If you copy to the clipboard saved response code and holding the Ctrl key set the cursor to 
 the fileld "A", the code will be inserted automatically.
*** If you hold Ctrl while typing a key in the key entry field, the key is installed and the forced 
 creation *** Activation Backup ***.  



Changes in versions:
v2.0.5
 - Fixed minor bugs.

v2.0.4
 - Added WebChat boottons.

v2.0.3
 -Fixed minor bugs.

v2.0.2
 -Fixed minor bugs.

v2.0.0
- First, a test version of the program.

 