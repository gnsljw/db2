Command Line Parameters:
  -Port <Port Value> - KMS Port. Range from 1 to 65535
         -PWin <PID> - Windows PID
         -PO14 <PID> - Office 2010 PID
         -PO15 <PID> - Office 2013 PID
         -PO16 <PID> - Office 2016 PID
      -AI <Interval> - Activation Interval. Range from 15 to 43200 minutes
      -RI <Interval> - Renewall Interval. Range from 15 to 43200 minutes
              -Debug - Detailed info.
                -Log - Log file Enabled.
        -Hwid <HWID> - Machine Hardware Hash.
Examples:
KMSSS /? | -?
or
KMSSS -Port 1688 -Pwin RandomKMSPID -PO14 RandomKMSPID -PO15 RandomKMSPID -PO16 RandomKMSPID -AI 43200 -RI 43200 -Log -Hwid DD279A0090B8D83E
or
sc.exe create KMSEmulator binPath= "KMSSS.exe -Port 1688 -PWin RandomKMSPID ...."  type= own start= auto

