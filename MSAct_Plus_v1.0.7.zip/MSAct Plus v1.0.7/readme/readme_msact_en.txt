﻿
	 		               MSAct Plus от Ratiborus
                                    ————————————————————————————


 			             The purpose of the program
                                     ————————————————————————————
The program is intended for installation key and activate Windows 7-10 and Office 2010-2013.
If the set key enables activation over the network, via the Internet, the product is activated
automatically, if this does not happen and the key is not blocked - the code is issued to transfer M$
Activation Center to activate by phone.
Unlike MSAct in the program MSAct Plus has the ability to create groups of keys for
different products.

                                       Work with the program
                                     ————————————————————————————
1. Select a product to install key and activation;
2. Type in the input box key the key for the selected product;
3. Click "Set key".

If the set key enables activation over the network, via the Internet, the product is activated
automatically, otherwise, if the key is not blocked, in boxes 1-9 display the code for sending 
the Activation Center M$ to activate by phone.
To activate by phone, you must call the Activation Center, send the code of the fields "1-9"
and to get the return code that must be entered in the field "A-H" and click "Apply".
If everything is completed without errors, the product is activated.
When activation is completed, you can save the key and the return code into a text file using 
special button. Subsequently, for example, after reinstalling the system, rather
will set key to enter the program previously stored return code and click "Apply".
Recovery activation is possible even if the key is already blocked.

*** If you copy to the clipboard saved response code and set the cursor to the fileld "A", the code
will be inserted automatically.
*** A button near the block "9" forcibly displays the code for transmitting to the Center
Activation, even if the key is blocked. This enables you to activate by phone, for
keys held online activation.

                                      Working with Database Keys
                                     ————————————————————————————
In the window Database Keys you can create your own group of keys, delete, add to group keys from the clipboard
share, load groups in the field for entering the key. After loading the group is available
automatic program mode. In this mode, all keys are processed by turns, until the product will be activated or end a list of keys.


Changes in versions:
v1.0.7
 -Changes in the interface.

v1.0.6
 -WebAct button added.

v1.0.5
-Fixed: Setting keys for Office 2016.

v1.0.4
-Fixed: Setting keys for Office 2013.

v1.0.3 
 -Added a parameter in the initialization file, named "NotStop". "NotStop=False" - check stops 
  when the product is activated, "NotStop=True" - check continues even if the product is activated. 
  For batch validation keys.

v1.0.2
 -Eliminated the "hang" program by adding the group large numbers of keys.
 -When you click the mouse on the system status indicator the system status window opens.
 -If the system is activated, before installing the key show a warning message 
  which can be turned off.

v1.0.1
 -On the Database tab Keys added buttons to "Copy keys", "Delete keys" of the group.
 -Added switch turns the logging program.
 -Above error messages are displayed key,  associated with error.
 -Added indicator "All products are activated."
 -Blocked keys are removed from the Database Keys and their copies placed in the file BLOCKED_KEYS _ $$$.txt,
  from which they can be added to the Blacklisted Base Keys in PIDKey utility.

v1.0.0
- First, a test version of the program.
 