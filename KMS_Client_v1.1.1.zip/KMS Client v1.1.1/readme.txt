[KMS Port] [KMS Host] [Client Mode]

KMS Port:
        DefaultPort:            Use the built-in KMS Port.
        Integer:                Number from 1 to 65535.

KMS Host:
        DefaultHost:            Use the built-in KMS Host Address.
        String:                 A DNS Name or IP Address.

Client Mode:
        Windows:                Windows Vista Enterprise KMS (V4) Client.
        WindowsVista:           Windows Vista Enterprise KMS (V4) Client.
        Windows7:               Windows 7 Enterprise KMS (V4) Client.
        Windows8:               Windows 8 Enterprise KMS (V5) Client.
        Windows81:              Windows 8 Enterprise KMS (V6) Client.
        Office2010:             Office 2010 Pro Plus KMS (V4) Client.
        Office2013:             Office 2013 Pro Plus KMS (V4) Client.
        Office2013V4:           Office 2013 Pro Plus KMS (V4) Client.
        Office2013V5:           Office 2013 Pro Plus KMS (V5) Client.

        Office2013V6:           Office 2013 Pro Plus KMS (V6) Client.

Example:
        C:\>KMSC.exe 1688 127.0.0.2 Windows