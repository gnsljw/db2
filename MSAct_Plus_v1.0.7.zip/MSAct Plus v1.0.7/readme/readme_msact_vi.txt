﻿
	 		   MSAct Plus của Ratiborus
			 ————————————————————————————


 			  Mục đích của chương trình
			————————————————————————————
Chương trình được thiết kế để giúp bạn kích hoạt Windows 7->10 và Office 2010-2013 dễ dàng hơn.
Nếu key bạn nhập vào c.trình có thể kích hoạt online, nó sẽ tự động kích hoạt và thông báo cho
bạn. Nếu không có mạng hoặc không thể kích hoạt online nó sẽ báo lỗi và đưa ra ID Step 2 để bạn
gọi điện đến tổng đài kích hoạt của M$ lấy ID xác nhận và tiến hành kích hoạt offline.
Ngoài ra bạn còn có thể tạo nhóm key cho các sản phẩm khác nhau để tiện cho việc kích hoạt.

 			    Sử dụng chương trình
			————————————————————————————
1. Chuẩn bị key sản phẩm bạn muốn kích hoạt;
2. Nhập key vào ô theo đúng định dạng quy định;
3. Nhấn nút "Set key".

Nếu key có thể kích hoạt online, nó sẽ tự động kích hoạt. Nếu không c.trình sẽ hiển thị dãy
ID Step 2 từ "1-9". Bạn lấy dãy ID đó và tiến hành kích hoạt qua Phone.
Để kích hoạt qua Phone, bạn gọi đến tổng đài kích hoạt của MS và đọc dãy ID từ "1-9" cho họ.
Nếu hợp lệ, họ sẽ đọc cho bạn 8 dãy ID từ "A-H". Bạn nhập tương ứng vào các ô bên dưới và
nhấn "Áp dụng". Nếu mọi thứ đều chính xác thì sản phẩm của bạn sẽ được kích hoạt.
Khi kích hoạt hoàn tất bạn có thể lưu key và ID xác nhận lại bằng cách nhấn nút lưu trong 
công cụ. Điều này rất quan trọng bởi bạn có thể kích hoạt lại bằng dãy ID tương ứng với key
đó vào lần sau ngay cả khi key bạn dùng đã bị chặn.

*** Mẹo: Nếu bạn gọi điện và ghi lại ID trong Notepad, bạn có thể copy và dán vào ô "A".
Dãy ID sẽ được nhập tự động.

 			          Nhóm key
			————————————————————————————
Trong cửa sổ Nhóm key, bạn có thể tạo nhóm key riêng, xóa hoặc thêm key vào nhóm từ Clipboard, 
Khi bạn nạp nhóm key vào c.trình, nó sẽ bắt đầu kiểm tra cho đến khi không thể kích hoạt hoặc
không thể hoàn kiểm tra.

                        Số điện thoại để kích hoạt 
                       ———————————————————————————— 
US:       8883527140    Miễn phí
Úc:       1800642008    Miễn phí
UK:       8000188354    Miễn phí
Nga:      88002008002   Miễn phí 
Estonia:  3728002230    Miễn phí    (Nhấn phím "2" để chuyển sang tổng đài của Nga)
			————————————————————————————


Các thay đổi:
v1.0.7
 -Changes in the interface.

v1.0.6
 -WebAct button added.

v1.0.5 
 -Fixed: Setting keys for Office 2016.

v1.0.4 
 -Fixed: Setting keys for Office 2013.

v1.0.3 
 -Added a parameter in the initialization file, named "NotStop". "NotStop=False" - check stops 
  when the product is activated, "NotStop=True" - check continues even if the product is activated. 
  For batch validation keys.

v1.0.2
 -Sửa lỗi treo máy khi kiểm tra nhiều phím.
 -Khi bạn click chuột vào các chỉ số tình trạng hệ thống, một bảng thông báo sẽ hiện ra.
 -Khi hệ thống của bạn đã kích hoạt, một thông báo sẽ hiện ra để bạn có thể tránh việc mất kích hoạt

v1.0.1
 -Chức năng nhóm key được bổ sung tính năng "Sao chép key", "Xóa key" khỏi nhóm.
 -Thêm chế độ lưu lại bản ghi khi làm việc.
 -Trên bản ghi sẽ xuất hiện lỗi và key bị lỗi.
 -Thêm thông báo "Tất cả sản phẩm đã kích hoạt".
 -Tất cả key bị chặn đều đã được lưu trong BLOCKED_KEYS_$$$.txt,
  bạn có thể thêm vào danh sách key bị chặn của PIDKey.

v1.0.0 
 -Phiên bản đầu tiên của chương trình.